<script setup lang="ts">

</script>

<template>
  <h2>WhatsApp Policy</h2>
  <p>We only use WhatsApp to respond to your inquiries or service requests and do not send unsolicited messages.</p>
  <p>If you wish to opt out of our WhatsApp notifications, please enter your number here.</p>
  <input type="text" placeholder="Your WhatsApp number">&nbsp;&nbsp;<a href="/whatsapp2" target="_blank"><button>Opt-Out from WhatsApp Notifications</button></a>
</template>

<style scoped>
</style>
