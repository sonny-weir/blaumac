<script setup lang="ts">

</script>

<template>
  <h2>WhatsApp Policy</h2>
  <p>You have successfully opted out of our WhatsApp notifications.</p>
</template>

<style scoped>
</style>
