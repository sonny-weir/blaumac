<script setup lang="ts">

</script>

<template>
  <h2>Privacy Policy</h2>
  
  <h3>Introduction</h3>
  <p>Welcome to Blaumac's Privacy Policy. Your privacy is critically important to us. We are committed to protecting your personal data and ensuring that we are transparent about the information we collect and what we do with it.</p>

  <h3>Data Controller</h3> 
  <p>Blaumac Consulting S.L., located at Plaça de Tirant lo Blanc 6, Barcelona, is the controller of your personal data.</p>

  <h3>Purpose for Processing Personal Data</h3>
  <p>We process personal data for the sole purpose of responding to inquiries made by you through WhatsApp. We will not use your data for marketing purposes or send you unsolicited messages.</p>

  <h3>Purpose for Processing Personal Data</h3>
  <p>We process personal data for the sole purpose of responding to inquiries or requests made by you. We will not use your data for marketing purposes or send you unsolicited messages.</p>

  <h3>Data We Collect</h3>
  <p>When you contact us via WhatsApp, we may collect the following data:</p>
  <ul>
      <li>Your mobile phone number</li>
      <li>Your name (as provided on WhatsApp)</li>
      <li>Any other data you choose to share with us in your message</li>
  </ul>

  <h3>Use of Data</h3>
  <p>We use the information you provide to:</p>
  <ul>
      <li>Respond to your inquiries</li>
      <li>Provide support or deliver services you've requested</li>
      <li>Maintain records of our interactions to improve our services</li>
  </ul>

  <h3>Sharing and Disclosure</h3>
  <p>We adhere to the WhatsApp Business Policy, which means:</p>
  <ul>
      <li>We will not use data obtained from WhatsApp about you for any purpose other than supporting messaging with you.</li>
      <li>We will not share or ask you to share sensitive identifiers.</li>
      <li>Information from a customer chat will not be shared with any other customer.</li>
  </ul>

  <h3>Data Storage and Security</h3>
  <p>Your data is stored securely, and we take reasonable precautions to ensure it is not accessed or disclosed to unauthorized individuals.</p>

  <h3>Your Rights under the GDPR</h3>
  <p>As we are based in the EU, you have rights under the General Data Protection Regulation (GDPR) regarding your personal data:</p>
  <ul>
      <li><strong>Access:</strong> You have the right to request a copy of the personal data we hold about you.</li>
      <li><strong>Correction:</strong> You can request to correct any inaccurate data we have about you.</li>
      <li><strong>Deletion:</strong> Under certain conditions, you can request that we delete your personal data.</li>
      <li><strong>Objection:</strong> You can object to the processing of your personal data.</li>
      <li><strong>Data Portability:</strong> You can request to transfer your data to another service provider.</li>
  </ul>
  <p>If you want to exercise any of these rights, please contact us at support@blaumac.com</p>

  <h3>Data Retention</h3>
  <p>We will retain your personal data for as long as necessary to fulfill the purposes we collected it for, including for the purposes of satisfying any legal or reporting requirements.</p>

  <h3>Third-party links</h3>
  <p>Our website or messages may, from time to time, contain links to third-party websites or services. Please note that these websites have their own privacy policies, and we do not accept any responsibility or liability for these policies.</p>

  <h3>Contacting Us</h3>
  <p>If you have any questions or concerns regarding this Privacy Policy, please contact us at support@blaumac.com or +34 617 752 918.</p>
</template>

<style scoped>
</style>
