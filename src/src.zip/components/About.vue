<script setup lang="ts">

</script>

<template>
  <p>Blaumac Consulting is a company that provides services in the field of information technology, and also operates a number of coworking spaces.</p>
</template>

<style scoped>
</style>
