<script setup lang="ts">

</script>

<template>
    <h2>Contact us</h2>
    <p>If you have any questions, concerns, or feedback, feel free to reach out to us via the following:</p>

    <p>Blaumac Consulting S.L.</p>
    <p>Plaça de Tirant lo Blanc, 6 Local, 08005 Barcelona</p>
    <p>support@blaumac.com</p>
    <p>+34617752918</p>
    <p>+34622475591</p>
</template>

<style scoped>
</style>
