<script setup lang="ts">
</script>

<template>
  <div class="logo">
    <img src="/logo.gif" alt="Blaumac logo">
  </div>
  <div>
    <nav>
      <ul>
        <li><router-link to="/about">About Us</router-link></li>
        <li><router-link to="/contact">Contact Us</router-link></li>
        <li><router-link to="/privacy">Privacy Policy</router-link></li>
        <li><router-link to="/whatsapp">WhatsApp Policy</router-link></li>
      </ul>
    </nav>

    <router-view></router-view>
  </div>
</template>

<style scoped>
  .logo {
    height: 3em;
    padding: 1.5em;
    will-change: filter;
    transition: filter 300ms;
  }
  body {
      font-family: Arial, sans-serif;
      margin: 0;
      padding: 0;
  }

  header, nav, footer {
      padding: 20px;
  }

  nav ul {
      list-style-type: none;
      padding: 0;
  }

  nav ul li {
      display: inline;
      margin-right: 20px;
  }



</style>
